<script setup>
import {
  nextTick,
  onBeforeUnmount,
  ref
} from 'vue'

import { Html5Qrcode } from 'html5-qrcode'

const emit = defineEmits([
  'close',
  'scanned'
])

const readerId = `cccd-reader-${Date.now()}`

const scanner = ref(null)
const fileInput = ref(null)

const starting = ref(false)
const scanning = ref(false)
const error = ref('')

let finished = false

/* ================================
   XỬ LÝ DỮ LIỆU CCCD
================================ */

function normalizeText(value) {
  return String(value ?? '').trim()
}

function parseDate(value) {
  const text = normalizeText(value)
    .replace(/\D/g, '')

  if (text.length !== 8) {
    return ''
  }

  const day = text.slice(0, 2)
  const month = text.slice(2, 4)
  const year = text.slice(4, 8)

  return `${year}-${month}-${day}`
}

function parseGender(value) {
  const text = normalizeText(value)
    .toLowerCase()

  if (text === 'nam') {
    return 1
  }

  if (
    text === 'nữ' ||
    text === 'nu'
  ) {
    return 2
  }

  return 0
}

function parseCccd(text) {
  const parts = String(text)
    .split('|')
    .map(item => item.trim())

  if (parts.length < 6) {
    throw new Error(
      'QR không đúng định dạng CCCD.'
    )
  }

  return {
    cccd: parts[0] || '',

    oldCccd: parts[1] || '',

    name: parts[2] || '',

    dob: parseDate(parts[3]),

    gender: parseGender(parts[4]),

    address: parts[5] || '',

    issueDate: parseDate(parts[6]),

    raw: text
  }
}

/* ================================
   CAMERA
================================ */

async function stopScanner() {
  const current = scanner.value

  if (!current) {
    scanning.value = false
    return
  }

  try {
    if (scanning.value) {
      await current.stop()
    }
  } catch (e) {
    console.warn(
      'Không thể dừng camera:',
      e
    )
  }

  try {
    await current.clear()
  } catch (e) {
    console.warn(e)
  }

  scanner.value = null
  scanning.value = false
}

async function handleSuccess(decodedText) {
  if (finished) {
    return
  }

  try {
    const data = parseCccd(decodedText)

    finished = true

    await stopScanner()

    emit('scanned', data)
  } catch (e) {
    error.value =
      e?.message ||
      'Không đọc được dữ liệu CCCD.'
  }
}

async function startScanner() {
  if (scanning.value) {
    return
  }

  error.value = ''
  starting.value = true
  finished = false

  await nextTick()

  try {
    await stopScanner()

    const html5QrCode =
      new Html5Qrcode(readerId)

    scanner.value = html5QrCode

    await html5QrCode.start(
      {
        facingMode: 'environment'
      },
      {
        fps: 10,

        qrbox: {
          width: 280,
          height: 180
        }
      },
      handleSuccess,
      () => {
        // QR chưa nằm đúng trong khung.
        // Không cần hiện lỗi từng frame.
      }
    )

    scanning.value = true
  } catch (e) {
    console.error(e)

    error.value =
      'Không mở được camera. Bạn có thể chọn ảnh QR CCCD bên dưới.'
  } finally {
    starting.value = false
  }
}

/* ================================
   QUÉT TỪ ẢNH
================================ */

function chooseImage() {
  fileInput.value?.click()
}

async function scanImage(event) {
  const file = event.target.files?.[0]

  if (!file) {
    return
  }

  error.value = ''
  finished = false

  try {
    /*
     * Dừng webcam trước khi dùng scanFile.
     */
    await stopScanner()

    await nextTick()

    const html5QrCode =
      new Html5Qrcode(readerId)

    scanner.value = html5QrCode

    const decodedText =
      await html5QrCode.scanFile(
        file,
        true
      )

    const data =
      parseCccd(decodedText)

    finished = true

    try {
      await html5QrCode.clear()
    } catch (e) {
      console.warn(e)
    }

    scanner.value = null

    emit('scanned', data)

  } catch (e) {
    console.error(e)

    error.value =
      'Không đọc được QR trong ảnh. ' +
      'Hãy chụp rõ mã QR trên CCCD và thử lại.'
  } finally {
    event.target.value = ''
  }
}

/* ================================
   ĐÓNG
================================ */

async function close() {
  finished = true

  await stopScanner()

  emit('close')
}

onBeforeUnmount(() => {
  stopScanner()
})

nextTick(() => {
  startScanner()
})
</script>

<template>
  <Teleport to="body">

    <div
      class="cccd-mask"
      @click.self="close"
    >

      <section class="cccd-modal">

        <!-- HEADER -->

        <div class="cccd-head">

          <div>
            <h2>
              <i class="bi bi-upc-scan"></i>
              Quét mã QR CCCD
            </h2>

            <p>
              Đưa mã QR trên CCCD vào giữa
              khung camera.
            </p>
          </div>

          <button
            type="button"
            class="cccd-close"
            @click="close"
          >
            <i class="bi bi-x-lg"></i>
          </button>

        </div>

        <!-- CAMERA -->

        <div
          :id="readerId"
          class="cccd-reader"
        ></div>

        <div
          v-if="starting"
          class="cccd-status"
        >
          <i class="bi bi-camera"></i>
          Đang mở camera...
        </div>

        <!-- ERROR -->

        <div
          v-if="error"
          class="cccd-error"
        >
          <i class="bi bi-exclamation-triangle"></i>

          <span>
            {{ error }}
          </span>
        </div>

        <!-- HƯỚNG DẪN -->

        <div class="cccd-note">

          <i class="bi bi-info-circle"></i>

          <div>
            <strong>
              Camera laptop bị mờ?
            </strong>

            <p>
              Hãy dùng điện thoại chụp rõ mã QR
              trên CCCD, gửi ảnh sang máy tính
              rồi chọn ảnh bên dưới.
            </p>
          </div>

        </div>

        <!-- INPUT FILE ẨN -->

        <input
          ref="fileInput"
          type="file"
          accept="image/*"
          hidden
          @change="scanImage"
        />

        <!-- BUTTON -->

        <div class="cccd-actions">

          <button
            type="button"
            class="ss-btn primary"
            @click="chooseImage"
          >
            <i class="bi bi-image"></i>
            Chọn ảnh QR CCCD
          </button>

          <button
            v-if="!scanning"
            type="button"
            class="ss-btn"
            @click="startScanner"
          >
            <i class="bi bi-camera"></i>
            Mở lại camera
          </button>

          <button
            type="button"
            class="ss-btn"
            @click="close"
          >
            Hủy
          </button>

        </div>

      </section>

    </div>

  </Teleport>
</template>

<style scoped>
.cccd-mask {
  position: fixed;
  inset: 0;

  z-index: 99999;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 20px;

  background:
    rgba(15, 23, 42, 0.58);
}

.cccd-modal {
  width: min(580px, 100%);

  max-height: 95vh;
  overflow-y: auto;

  padding: 22px;

  background: #ffffff;

  border-radius: 18px;

  box-shadow:
    0 25px 70px
    rgba(15, 23, 42, 0.28);
}

.cccd-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;

  margin-bottom: 18px;
}

.cccd-head h2 {
  display: flex;
  align-items: center;

  gap: 8px;

  margin: 0;

  font-size: 20px;
}

.cccd-head p {
  margin: 6px 0 0;

  color: #64748b;

  font-size: 13px;
}

.cccd-close {
  width: 36px;
  height: 36px;

  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border: 0;
  border-radius: 10px;

  background: #f1f5f9;
  color: #475569;

  cursor: pointer;
}

.cccd-close:hover {
  background: #e2e8f0;
}

.cccd-reader {
  width: 100%;

  min-height: 280px;

  overflow: hidden;

  border-radius: 14px;

  background: #0f172a;
}

.cccd-status {
  margin-top: 12px;

  color: #64748b;

  font-size: 13px;
}

.cccd-error {
  display: flex;
  align-items: flex-start;

  gap: 8px;

  margin-top: 14px;

  padding: 12px 14px;

  border-radius: 10px;

  color: #b91c1c;
  background: #fef2f2;

  font-size: 13px;
}

.cccd-note {
  display: flex;
  align-items: flex-start;

  gap: 10px;

  margin-top: 14px;

  padding: 12px 14px;

  border-radius: 10px;

  color: #475569;
  background: #f8fafc;

  font-size: 13px;
}

.cccd-note strong {
  color: #334155;
}

.cccd-note p {
  margin: 4px 0 0;

  line-height: 1.5;
}

.cccd-actions {
  display: flex;
  justify-content: flex-end;
  flex-wrap: wrap;

  gap: 8px;

  margin-top: 18px;
}

@media (max-width: 640px) {
  .cccd-mask {
    padding: 10px;
  }

  .cccd-modal {
    padding: 16px;
  }

  .cccd-actions {
    flex-direction: column;
  }

  .cccd-actions button {
    width: 100%;
  }
}
</style>
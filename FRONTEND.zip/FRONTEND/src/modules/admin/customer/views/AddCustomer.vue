<script setup>
import AdminLayout from '../../../../layouts/AdminLayout.vue'
import AvatarCard from '../../../../components/AvatarCard.vue'
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAddressApi } from '../../../../composables/useAddressApi'
import customerService from '../services/customerService'
import AppToast from '../../../../components/AppToast.vue'
import ConfirmModal from '../../../../components/ConfirmModal.vue'
import { useToast } from '../../../../composables/useToast'

const {
  toast,
  success,
  error: showError,
  closeToast
} = useToast()

const confirmModal = ref({
  show: false,
  action: null
})

const confirmLoading = ref(false)

function closeConfirm() {
  if (confirmLoading.value) return

  confirmModal.value.show = false
  confirmModal.value.action = null
}

async function executeConfirm() {
  if (!confirmModal.value.action) return

  confirmLoading.value = true

  try {
    await confirmModal.value.action()
  } finally {
    confirmLoading.value = false
    confirmModal.value.show = false
    confirmModal.value.action = null
  }
}

const router = useRouter()

const f = ref({
  name: '',
  email: '',
  phone: '',
  gender: '',
  dob: '',
  image: '',

  rName: '',
  rPhone: '',

  province: '',
  ward: '',
  street: '',

  addressType: 1
})

const {
  provinces,
  wards,

  provinceCode,
  wardCode,

  loadingProvinces,
  loadingWards,

  addressError,

  changeProvince,
  changeWard
} = useAddressApi(f)

const err = ref('')
const saving = ref(false)

const errorMessage = (e) =>
  e?.response?.data?.message ||
  'Không thể tạo khách hàng, vui lòng thử lại.'

async function save() {
  const v = f.value

  if (
    !v.name.trim() ||
    !v.email.trim() ||
    !v.rName.trim() ||
    !v.rPhone.trim() ||
    !v.province ||
    !v.ward ||
    !v.street.trim()
  ) {
    err.value =
      'Vui lòng nhập đầy đủ các trường bắt buộc (*).'
    return
  }

  if (
    !/^\S+@\S+\.\S+$/.test(v.email)
  ) {
    err.value =
      'Email không hợp lệ.'
    return
  }

  if (
    v.phone &&
    !/^0\d{9}$/.test(v.phone)
  ) {
    err.value =
      'Số điện thoại khách hàng phải gồm 10 số và bắt đầu bằng 0.'
    return
  }

  if (
    !/^0\d{9}$/.test(v.rPhone)
  ) {
    err.value =
      'Số điện thoại người nhận phải gồm 10 số và bắt đầu bằng 0.'
    return
  }

  if (
    v.dob &&
    new Date(v.dob) > new Date()
  ) {
    err.value =
      'Ngày sinh không được lớn hơn ngày hiện tại.'
    return
  }

  saving.value = true
  err.value = ''

  try {
    /*
     * AvatarCard đang tạo Base64.
     * Tạm thời không gửi Base64 xuống DB.
     */
    const image =
      v.image?.startsWith('data:image/')
        ? null
        : (v.image || null)

    await customerService.createCustomer({
      name: v.name.trim(),

      email: v.email.trim(),

      phone:
        v.phone.trim() || null,

      gender:
        v.gender === ''
          ? null
          : Number(v.gender),

      dob:
        v.dob || null,

      image,

      defaultAddress: {
        receiverName:
          v.rName.trim(),

        receiverPhone:
          v.rPhone.trim(),

        province:
          v.province,

        district:
          null,

        ward:
          v.ward,

        street:
          v.street.trim(),

        addressType:
          Number(v.addressType),

        isDefault:
          true
      }
    })

    success(
  'Thêm khách hàng thành công',
  'Thêm thành công'
)

    router.push('/khach-hang')

  } catch (e) {
    err.value = errorMessage(e)

  } finally {
    saving.value = false
  }
}
</script>

<template>
  <AppToast
  :show="toast.show"
  :type="toast.type"
  :title="toast.title"
  :message="toast.message"
  @close="closeToast"
/>
  <AdminLayout>
    <main class="ss-page">

      <div>
        <button
          class="ss-back"
          aria-label="Quay lại"
          @click="router.push('/khach-hang')"
        >
          <i class="bi bi-arrow-left"></i>
        </button>
      </div>

      <div class="ss-split">

        <AvatarCard
          v-model:image="f.image"
          :name="f.name"
          :email="f.email"
          fallback="KH"
        />

        <div class="ss-stack">

          <section class="ss-card ss-form">

            <div class="ss-head">

              <div class="ss-head-icon">
                <i class="bi bi-person"></i>
              </div>

              <div>
                <h2>
                  Thông tin cơ bản
                </h2>

                <p>
                  Họ tên, email, liên hệ
                  và tài khoản.
                </p>
              </div>

            </div>

            <div class="ss-grid2">

              <div class="ss-field">
                <label class="ss-label">
                  Họ và tên
                  <span class="req">*</span>
                </label>

                <input
                  class="ss-input"
                  v-model="f.name"
                  placeholder="Nhập họ tên"
                />
              </div>

              <div class="ss-field">
                <label class="ss-label">
                  Email
                  <span class="req">*</span>
                </label>

                <input
                  class="ss-input"
                  type="email"
                  v-model="f.email"
                  placeholder="Nhập email"
                />
              </div>

              <div class="ss-field">
                <label class="ss-label">
                  Số điện thoại
                </label>

                <input
                  class="ss-input"
                  v-model="f.phone"
                  placeholder="VD: 0901234567"
                />
              </div>

              <div class="ss-field">

                <label class="ss-label">
                  Giới tính
                </label>

                <select
                  class="ss-select"
                  v-model="f.gender"
                >
                  <option value="">
                    -- Chọn giới tính --
                  </option>

                  <option :value="1">
                    Nam
                  </option>

                  <option :value="2">
                    Nữ
                  </option>

                  <option :value="0">
                    Khác
                  </option>

                </select>

              </div>

              <div class="ss-field">

                <label class="ss-label">
                  Ngày sinh
                </label>

                <input
                  class="ss-input"
                  type="date"
                  v-model="f.dob"
                />

              </div>

            </div>

          </section>

          <section class="ss-card ss-form">

            <div class="ss-head">

              <div class="ss-head-icon">
                <i class="bi bi-geo-alt"></i>
              </div>

              <div>
                <h2>
                  Địa chỉ giao hàng
                </h2>

                <p>
                  Địa chỉ mặc định của
                  khách hàng mới.
                </p>
              </div>

            </div>

            <div class="ss-grid2">

              <div class="ss-field">

                <label class="ss-label">
                  Họ tên người nhận
                  <span class="req">*</span>
                </label>

                <input
                  class="ss-input"
                  v-model="f.rName"
                  placeholder="Họ tên người nhận"
                />

              </div>

              <div class="ss-field">

                <label class="ss-label">
                  Số điện thoại
                  <span class="req">*</span>
                </label>

                <input
                  class="ss-input"
                  v-model="f.rPhone"
                  placeholder="VD: 0901234567"
                />

              </div>

              <div class="ss-field">

  <label class="ss-label">
    Tỉnh/Thành phố
    <span class="req">*</span>
  </label>

  <select
    class="ss-select"
    v-model="provinceCode"
    :disabled="loadingProvinces"
    @change="changeProvince"
  >

    <option value="">
      {{
        loadingProvinces
          ? 'Đang tải...'
          : '-- Chọn tỉnh/thành --'
      }}
    </option>

    <option
      v-for="p in provinces"
      :key="p.code"
      :value="String(p.code)"
    >
      {{ p.name }}
    </option>

  </select>

</div>

<div class="ss-field">

  <label class="ss-label">
    Phường/Xã
    <span class="req">*</span>
  </label>

  <select
    class="ss-select"
    v-model="wardCode"
    :disabled="!provinceCode || loadingWards"
    @change="changeWard"
  >

    <option value="">
      {{
        loadingWards
          ? 'Đang tải...'
          : '-- Chọn phường/xã --'
      }}
    </option>

    <option
      v-for="w in wards"
      :key="w.code"
      :value="String(w.code)"
    >
      {{ w.name }}
    </option>

  </select>

</div>

<p v-if="addressError" class="text-danger">
  {{ addressError }}
</p>

              <div class="ss-field">

                <label class="ss-label">
                  Loại địa chỉ
                </label>

                <select
                  class="ss-select"
                  v-model="f.addressType"
                >

                  <option :value="1">
                    Nhà riêng
                  </option>

                  <option :value="2">
                    Văn phòng
                  </option>

                </select>

              </div>

              <div class="ss-field full">

                <label class="ss-label">
                  Địa chỉ cụ thể
                  <span class="req">*</span>
                </label>

                <input
                  class="ss-input"
                  v-model="f.street"
                  placeholder="Số nhà, tên đường..."
                />

              </div>

            </div>

            <p
              v-if="err"
              class="ss-hint warn"
            >
              <i class="bi bi-exclamation-triangle"></i>
              {{ err }}
            </p>

            <div class="ss-actions left">

              <button
                class="ss-btn primary"
                :disabled="saving"
                @click="save"
              >
                {{
                  saving
                    ? 'Đang tạo...'
                    : 'Tạo khách hàng'
                }}
              </button>

              <button
                class="ss-btn"
                @click="router.push('/khach-hang')"
              >
                Hủy
              </button>

            </div>

          </section>

        </div>
      </div>
    </main>
  </AdminLayout>
</template>